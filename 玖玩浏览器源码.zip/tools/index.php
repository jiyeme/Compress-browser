<?php
header('location: /?r='.rand(0,999));