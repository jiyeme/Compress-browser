<?php
!defined('m') && header('location: /?r='.rand(0,999));

error_show('网盘文件下载','对不起，您要下载的文件不存在或者链接失效！');