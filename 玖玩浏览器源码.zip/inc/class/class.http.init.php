<?php
/*
 *
 *	HTTP通讯类
 *
 *	2012/7/26 星期四 @ jiuwap.cn [原创]转载或使用请保留注释,谢谢
 *
 */

require_once 'class.http.fsockopen.php';

class httplib Extends http_fsockopen{}