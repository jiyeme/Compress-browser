<?php
//浏览器首页导航站点

$site[] = array('title' => 'QQ','url' => 'http://3g.qq.com');
$site[] = array('title' => '百度','url' => 'http://www.baidu.com');
$site[] = array('title' => '淘宝','url' => 'http://wap.taobao.com');
//$site[] = array('title' => 'UC论坛','url' => 'http://mbbs.uc.cn/bbs_ucweb/http/bbs.uc.cn/index.php');