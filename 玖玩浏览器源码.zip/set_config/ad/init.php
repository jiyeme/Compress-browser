<?php

//返回字符串(广告)
//将在浏览的页面底部直接显示，请自行提供广告显示算法。
function init_ad(){
	return '';
}

//暂时无用，请勿修改。
function init_ad_index(){
	return '';
}


//暂时无用，请勿修改。
function init_ad_api(){
	return '';
}
